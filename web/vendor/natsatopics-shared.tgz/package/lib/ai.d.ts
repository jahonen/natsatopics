import { NewsItem, DraftOption, Pillar, SocialPlatform } from './types';
export interface AiModelConfig {
    model?: string;
    location?: string;
}
export interface RelevanceClassification {
    relevant: boolean;
    redFlagged: boolean;
    redFlagReasons: string[];
    pillar: Pillar | null;
    reasoning: string;
}
/**
 * Vaihe 2 & osittain vaihe 3: asks the model to judge, using the full content
 * guide as context, whether a scraped news item clears the red-flag list in
 * luku 8.3 and, if so, which sisältöpilari (luku 6) it best fits.
 */
export declare function classifyNewsItem(projectId: string, news: NewsItem, config?: AiModelConfig): Promise<RelevanceClassification>;
export interface DraftGenerationResult {
    options: DraftOption[];
}
/**
 * Vaihe 4 — Luonnostelu. Generates exactly three draft options for a given
 * news item and pillar, following luku 11's julkaisumallit and the tone,
 * vocabulary and register rules in luvut 5 and 7.
 */
export declare function generateDrafts(projectId: string, news: NewsItem, pillar: Pillar, config?: AiModelConfig): Promise<DraftGenerationResult>;
/**
 * Nostalgia- ja historiapilarit (luku 6) eivät synny uutissyötteestä vaan
 * omasta aihepankista (packages/shared/contentBank.ts). Tämä generoi kolme
 * vaihtoehtoista postausta yhdestä pankin valmiiksi kirjoitetusta aiheesta
 * tai kysymyksestä, samoja rekisteri-, sanasto- ja sävysääntöjä noudattaen.
 */
export declare function generateBankDrafts(projectId: string, bankPrompt: string, pillar: Pillar, config?: AiModelConfig): Promise<DraftGenerationResult>;
/**
 * Vaihe 7 (julkaisupipeline): if the editor-approved final text does not fit
 * a platform's character limit, ask the model to shorten it while preserving
 * meaning, tone and the single audience question, per the same guide rules.
 */
export declare function adaptForPlatform(projectId: string, finalText: string, platform: SocialPlatform, config?: AiModelConfig): Promise<string>;
