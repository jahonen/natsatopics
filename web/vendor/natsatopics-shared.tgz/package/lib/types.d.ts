export type Pillar = 'nostalgia' | 'geopolitics' | 'reserve' | 'history';
export declare const PILLAR_TARGET_SHARE: Record<Pillar, number>;
export type PostTemplate = 'A' | 'B' | 'C' | 'D';
export type SocialPlatform = 'facebook' | 'threads' | 'bluesky';
export declare const PLATFORM_CHAR_LIMITS: Record<SocialPlatform, number>;
export interface NewsItem {
    title: string;
    url: string;
    summary: string;
    publishedAt: string;
    feedCategory: string;
    tags?: string[];
}
export interface RedFlagCheck {
    flagged: boolean;
    reasons: string[];
}
export interface DraftOption {
    id: string;
    text: string;
    template: PostTemplate;
}
export type DraftStatus = 'pending_review' | 'approved' | 'published' | 'rejected' | 'expired';
export interface PlatformPostResult {
    status: 'pending' | 'posted' | 'failed';
    text?: string;
    postId?: string;
    postUrl?: string;
    postedAt?: string;
    error?: string;
}
export interface DraftDocument {
    id: string;
    date: string;
    createdAt: string;
    sourceNews?: NewsItem;
    pillar: Pillar;
    options: DraftOption[];
    selectedOptionId?: string;
    finalText?: string;
    status: DraftStatus;
    magicToken: string;
    tokenExpiresAt: string;
    editorEmail: string;
    platformPosts?: Partial<Record<SocialPlatform, PlatformPostResult>>;
}
export interface WeeklyPillarCounts {
    isoWeek: string;
    counts: Record<Pillar, number>;
}
export interface ContentBankItem {
    id: string;
    pillar: 'nostalgia' | 'history';
    prompt: string;
    used: boolean;
    lastUsedDate?: string;
}
export interface WeeklyAnalyticsStats {
    isoWeek: string;
    rangeStart: string;
    rangeEnd: string;
    totalDrafts: number;
    publishedCount: number;
    rejectedCount: number;
    pendingCount: number;
    pillarCounts: Record<Pillar, number>;
    pillarShares: Record<Pillar, number>;
    pillarDeltas: Record<Pillar, number>;
    templateCounts: Partial<Record<PostTemplate, number>>;
    platformStats: Record<SocialPlatform, {
        posted: number;
        failed: number;
        adapted: number;
    }>;
    contentBankRemaining: Record<'nostalgia' | 'history', number>;
    recommendations: string[];
}
