import type { Firestore } from 'firebase-admin/firestore';
import { ContentBankItem } from './types';
/**
 * Luku 6: nostalgia- ja historiapilarit eivät synny uutissyötteestä, vaan
 * vaativat oman, etukäteen rakennetun aihepankin. Poimii pankista vanhimman
 * käyttämättömän (tai pisimpään käyttämättömän) alkion annetulle pilarille.
 */
export declare function pickBankItem(db: Firestore, pillar: 'nostalgia' | 'history'): Promise<ContentBankItem | null>;
export declare function markBankItemUsed(db: Firestore, id: string, date: string): Promise<void>;
