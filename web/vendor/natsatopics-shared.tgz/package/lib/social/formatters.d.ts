import { SocialPlatform } from '../types';
export interface FormatResult {
    text: string;
    withinLimit: boolean;
    charCount: number;
    limit: number;
}
/** Grapheme-aware length check (good enough for Bluesky's grapheme-cluster limit). */
export declare function graphemeLength(text: string): number;
export declare function checkPlatformLength(platform: SocialPlatform, text: string): FormatResult;
