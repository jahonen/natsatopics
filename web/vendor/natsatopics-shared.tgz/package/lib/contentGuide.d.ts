/**
 * Loads the Natsastore content guide (sisältöopas). The canonical source is
 * assets/natsastore-sisaltoopas.md at the repo root; the shared package's
 * build step (scripts/copy-guide.js) copies it into lib/content/guide.md so
 * it ships inside this package for both the functions backend and the web
 * app to consume at runtime.
 */
export declare function loadContentGuide(): string;
