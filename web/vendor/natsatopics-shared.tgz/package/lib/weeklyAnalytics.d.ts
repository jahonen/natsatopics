import { DraftDocument, WeeklyAnalyticsStats } from './types';
/**
 * Pure function (no Firestore access) that turns a week's worth of drafts
 * plus current content-bank remaining counts into stats + Finnish-language
 * recommendations. Kept separate from the Firestore query (in
 * functions/src/weeklyAnalyticsJob.ts) so the analysis logic itself is
 * unit-testable without an emulator.
 */
export declare function computeWeeklyStats(isoWeek: string, rangeStart: string, rangeEnd: string, drafts: DraftDocument[], contentBankRemaining: Record<'nostalgia' | 'history', number>): WeeklyAnalyticsStats;
