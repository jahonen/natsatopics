import { NewsItem, RedFlagCheck } from './types';
export declare function quickRedFlagCheck(news: NewsItem): RedFlagCheck;
