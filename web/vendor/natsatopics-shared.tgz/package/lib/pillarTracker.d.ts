import type { Firestore } from 'firebase-admin/firestore';
import { Pillar, WeeklyPillarCounts } from './types';
/** ISO week identifier, e.g. "2026-W31", in Europe/Helsinki local time. */
export declare function isoWeekId(date: Date): string;
export declare function getWeeklyCounts(db: Firestore, isoWeek: string): Promise<WeeklyPillarCounts>;
export declare function recordPillarUse(db: Firestore, isoWeek: string, pillar: Pillar): Promise<void>;
/**
 * Chooses which pillar today's proposal(s) should target, per Vaihe 3 of the
 * daily process: if the week's distribution is already skewed away from the
 * guide's target shares, prefer the most under-represented pillar over
 * whatever a news-driven proposal would naturally fall into.
 */
export declare function pickUnderrepresentedPillar(counts: Record<Pillar, number>): Pillar;
